pip install file requirement
# chạy file 
npm run dev
